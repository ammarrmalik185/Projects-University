﻿namespace Lab3
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            
        }
    }
}