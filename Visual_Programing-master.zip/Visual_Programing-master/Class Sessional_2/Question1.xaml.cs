﻿using System.Windows;
using System.Linq;

namespace Class_Sessional_2
{
    public partial class Question1 : Window
    {
        public Question1()
        {
            InitializeComponent();
            
            /*Sir, My Microsoft SQL Server Express 2016 was not functioning properly
            so i was not able to create a database however i have added the code to execute the function. 
            Employee db = new Employee();
            var sortedList = from employee in db.Employees
                orderby employee.First_Name + employee.Last_Name
                select employee;

            foreach (var employee in sortedList.ToList()) {
                ListBox.Items.Add(employee);
            }*/
        }
    }
}