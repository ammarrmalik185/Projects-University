﻿namespace MongoDB_Test
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            //var client = new MongoClient("mongodb+srv://aseed:ammar@xcluster.o3kj5.gcp.mongodb.net/myFirstDatabase?retryWrites=true&w=majority");
            //var database = client.GetDatabase("test");
        }
    }
}