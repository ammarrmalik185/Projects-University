﻿using System.Windows;

namespace WPFPractice
{
    public partial class Calculator : Window
    {
        public Calculator()
        {
            InitializeComponent();
        }
    }
}