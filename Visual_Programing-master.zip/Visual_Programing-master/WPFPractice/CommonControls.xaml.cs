﻿using System.Windows;

namespace WPFPractice
{
    public partial class CommonControls : Window
    {
        public CommonControls()
        {
            InitializeComponent();
        }
    }
}