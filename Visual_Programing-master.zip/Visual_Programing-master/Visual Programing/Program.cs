﻿namespace Visual_Programing
{
    internal class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}