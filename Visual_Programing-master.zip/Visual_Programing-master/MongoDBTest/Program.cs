﻿using System;

namespace MongoDBTest
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Console.Write("Hello");
        }
    }
}