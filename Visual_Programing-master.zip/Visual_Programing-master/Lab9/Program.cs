﻿namespace Lab9
{
    internal class Program
    {
        public static void Main(string[] args) {
            
        }
    }
}