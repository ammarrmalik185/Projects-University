const blogModel = require('../models/blogModel')
const mongoose = require("mongoose");

module.exports.blogPost = function (req, res, next) {
    console.log(req.body)
    new blogModel(req.body).save()
    res.json("created")
}

module.exports.blogGet = function (req, res, next) {
    blogModel.find({}).exec((err, data) => {
        if (err) throw err
        console.log(data)
        res.json(data)

    })
}

module.exports.singleBlogGet = function (req, res, next) {
    blogModel.find({_id : new mongoose.Types.ObjectId(req.params.blogId)})
        .exec((err, data) => {
        if (err) throw err
        console.log(data)
            res.json(data)

    })
}

module.exports.singleBlogUpdate = function (req, res, next) {
    blogModel.findOneAndUpdate({_id : new mongoose.Types.ObjectId(req.params.blogId)}, req.body)
        .exec((err, data) => {
        if (err) throw err
        console.log(data)
        res.json(data)

    })
}

module.exports.singleBlogDelete = function (req, res, next) {
    blogModel.findOneAndDelete({_id : new mongoose.Types.ObjectId(req.params.blogId)})
        .exec((err, data) => {
            if (err) throw err
            console.log(data)
            res.json(null)

        })
}
