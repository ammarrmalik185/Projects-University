export const Home = ()=>{
    var user = 'User'
    return(
        <>
            <pre><h1>Hello <em>{user}</em></h1></pre>
            <div align='center'>
                <h1>You're at the Home Page of a Blog Publishing Portal</h1>
            </div>
        </>
    )
}