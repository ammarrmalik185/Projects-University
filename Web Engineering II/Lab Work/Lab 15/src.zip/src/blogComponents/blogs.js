export const blogs = [
    {
        blog_id: 1,
        title: 'My First Title',
        snippet:'My First Snippet',
        body: 'My First Body'
    },
    {
        blog_id: 2,
        title: 'My Second Title',
        snippet:'My Second Snippet',
        body: 'My Second Body'
    },
    {
        blog_id: 3,
        title: 'My Third Title',
        snippet:'My Third Snippet',
        body: 'My Third Body'
    },
]