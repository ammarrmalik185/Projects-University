module.exports.main = function(req, res, next) {
    res.json('respond with a resource');
}
