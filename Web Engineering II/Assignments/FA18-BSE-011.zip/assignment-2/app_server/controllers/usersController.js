module.exports.main = function(req, res, next) {
    res.render('users');
}
